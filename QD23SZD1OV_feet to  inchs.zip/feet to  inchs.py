h =float(input())
print(h*12)